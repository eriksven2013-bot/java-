package com.example.storyengine.net;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Player -> server: "I picked this episode in the journal". The server checks it before doing anything. */
public record StartEpisodePayload(String episodeId) implements CustomPayload {
    public static final CustomPayload.Id<StartEpisodePayload> ID =
        new CustomPayload.Id<>(Identifier.of("storyengine", "start_episode"));

    public static final PacketCodec<RegistryByteBuf, StartEpisodePayload> CODEC =
        PacketCodec.tuple(PacketCodecs.STRING, StartEpisodePayload::episodeId, StartEpisodePayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
