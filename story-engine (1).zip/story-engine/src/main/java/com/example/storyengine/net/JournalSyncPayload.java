package com.example.storyengine.net;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Server -> player: "here is the journal". The journal is sent as JSON text,
 * so the journal screen always shows what the server's journal.json says.
 */
public record JournalSyncPayload(String json) implements CustomPayload {
    public static final CustomPayload.Id<JournalSyncPayload> ID =
        new CustomPayload.Id<>(Identifier.of("storyengine", "journal_sync"));

    // PacketCodecs.STRING allows text up to 32,767 characters, plenty for a journal.
    public static final PacketCodec<RegistryByteBuf, JournalSyncPayload> CODEC =
        PacketCodec.tuple(PacketCodecs.STRING, JournalSyncPayload::json, JournalSyncPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
