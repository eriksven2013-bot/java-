package com.example.storyengine.client;

import com.example.storyengine.Journal;
import com.example.storyengine.net.JournalSyncPayload;
import com.google.gson.Gson;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * The client-only part: the J key and the journal screen.
 * Fabric only loads this class on a player's game, never on a dedicated server.
 */
public class StoryEngineClient implements ClientModInitializer {
    /** The latest journal the server sent us (null until we join a world). */
    private static volatile Journal journal;
    private static KeyBinding openJournalKey;

    @Override
    public void onInitializeClient() {
        // When the server sends us the journal, remember it.
        ClientPlayNetworking.registerGlobalReceiver(JournalSyncPayload.ID, (payload, context) ->
            journal = new Gson().fromJson(payload.json(), Journal.class));

        // Register the "Open Journal" key (J). Players can rebind it in Options > Controls.
        openJournalKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.storyengine.journal",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_J,
            KeyBinding.Category.create(Identifier.of("storyengine", "main"))
        ));

        // Check for key presses once per client tick.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openJournalKey.wasPressed()) {
                if (client.player == null) continue;
                if (journal == null) {
                    client.player.sendMessage(Text.literal("The journal hasn't loaded yet (is Story Engine on the server?)."), false);
                } else {
                    client.setScreen(new JournalScreen(journal));
                }
            }
        });
    }
}
