package com.example.storyengine;

import com.google.gson.Gson;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;

/**
 * Finds and loads story files from the game's config folder:
 *   <game folder>/config/storyengine/stories/*.json
 * The file name (without ".json") is the name you type in /story play <name>.
 */
public class StoryLibrary {
    private static final Gson GSON = new Gson();

    /** Story files shipped inside the jar (in src/main/resources/assets/storyengine/stories/). */
    private static final String[] BUNDLED = { "example.json", "forgotten_dimension.json" };

    private final Path folder = FabricLoader.getInstance().getConfigDir().resolve("storyengine").resolve("stories");
    private final Map<String, Story> stories = new TreeMap<>();

    /** (Re)loads every story file. Safe to call again for /story reload. */
    public void load() {
        stories.clear();
        try {
            Files.createDirectories(folder);
            copyExampleIfEmpty();

            try (Stream<Path> files = Files.list(folder)) {
                files.filter(p -> p.toString().endsWith(".json")).forEach(this::loadOne);
            }
        } catch (IOException e) {
            StoryEngineMod.LOGGER.error("Could not read the stories folder", e);
        }
        StoryEngineMod.LOGGER.info("Loaded {} stories from {}", stories.size(), folder);
    }

    private void loadOne(Path file) {
        String fileName = file.getFileName().toString();
        String id = fileName.substring(0, fileName.length() - ".json".length());
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            Story story = GSON.fromJson(reader, Story.class);
            if (story != null && story.steps != null) {
                stories.put(id, story);
            }
        } catch (Exception e) {
            // One broken file shouldn't stop the others from loading.
            StoryEngineMod.LOGGER.error("Story file {} is broken: {}", fileName, e.getMessage());
        }
    }

    /** On first launch the folder is empty, so we copy the example story out of the mod jar. */
    private void copyExampleIfEmpty() throws IOException {
        try (Stream<Path> files = Files.list(folder)) {
            if (files.findAny().isPresent()) return;
        }
        // Every story bundled inside the mod jar gets copied out on first launch.
        for (String fileName : BUNDLED) {
            try (InputStream in = StoryLibrary.class.getResourceAsStream("/assets/storyengine/stories/" + fileName)) {
                if (in != null) {
                    Files.copy(in, folder.resolve(fileName));
                }
            }
        }
    }

    public Story get(String id) {
        return stories.get(id);
    }

    public Iterable<String> ids() {
        return stories.keySet();
    }

    public Path folder() {
        return folder;
    }
}
