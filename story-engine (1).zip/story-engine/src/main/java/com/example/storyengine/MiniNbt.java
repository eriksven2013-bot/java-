package com.example.storyengine;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * A very small reader for NBT files (the format .schem schematics use).
 *
 * We read it ourselves instead of using Minecraft's NBT classes, because those change between
 * Minecraft versions, while the file format itself never does.
 *
 * Everything comes back as plain Java objects:
 *   compound -> Map<String, Object>      list -> List<Object>
 *   byte[] / int[] / long[] -> arrays    numbers -> Byte/Short/Integer/Long/Float/Double
 *   string -> String
 */
public final class MiniNbt {
    private MiniNbt() {}

    /** Reads a gzip-compressed NBT file and returns its root compound. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> readGzipped(Path file) throws IOException {
        try (InputStream raw = Files.newInputStream(file);
             DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(raw)))) {
            int type = in.readUnsignedByte();
            if (type != 10) throw new IOException("Not an NBT file (root tag is not a compound)");
            in.readUTF(); // the root tag's name, which we don't need
            return (Map<String, Object>) readPayload(in, 10);
        }
    }

    private static Object readPayload(DataInputStream in, int type) throws IOException {
        switch (type) {
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: {
                byte[] bytes = new byte[in.readInt()];
                in.readFully(bytes);
                return bytes;
            }
            case 8: return in.readUTF();
            case 9: {
                int itemType = in.readUnsignedByte();
                int count = in.readInt();
                List<Object> list = new ArrayList<>();
                for (int i = 0; i < count; i++) list.add(readPayload(in, itemType));
                return list;
            }
            case 10: {
                Map<String, Object> map = new LinkedHashMap<>();
                while (true) {
                    int childType = in.readUnsignedByte();
                    if (childType == 0) break; // 0 = end of compound
                    String name = in.readUTF();
                    map.put(name, readPayload(in, childType));
                }
                return map;
            }
            case 11: {
                int[] ints = new int[in.readInt()];
                for (int i = 0; i < ints.length; i++) ints[i] = in.readInt();
                return ints;
            }
            case 12: {
                long[] longs = new long[in.readInt()];
                for (int i = 0; i < longs.length; i++) longs[i] = in.readLong();
                return longs;
            }
            default:
                throw new IOException("Unknown NBT tag type " + type);
        }
    }
}
