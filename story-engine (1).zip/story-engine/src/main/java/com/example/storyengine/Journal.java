package com.example.storyengine;

import java.util.List;

/**
 * The contents of the journal: who you can play as, and which episodes exist.
 * Loaded from config/storyengine/journal.json (Gson fills these fields from the JSON,
 * so the names here must match the keys in that file). The server also sends the
 * same JSON text to every player so their journal screen can show it.
 */
public class Journal {
    public List<Hero> characters = List.of();
    /** Each character's story is split into arcs, shown in this order. */
    public List<Arc> arcs = List.of();
    public List<Episode> episodes = List.of();

    /** A chapter of a character's story, such as "Empire Arc". It holds episodes. */
    public static class Arc {
        public String id = "";
        public String name = "";
        /** The id of the character this arc belongs to. */
        public String character = "";
        public String description = "";
    }

    /** A character you can pick in the journal. */
    public static class Hero {
        public String id = "";
        public String name = "";
        public String description = "";
    }

    /** One episode of the story. */
    public static class Episode {
        public String id = "";
        public String title = "";
        /** The id of the arc this episode belongs to (the arc knows which character it is). */
        public String arc = "";
        public String description = "";
        /** false = shown in the journal as "coming soon" and can't be started. */
        public boolean playable = false;
        /** The id of the story file (config/storyengine/stories/<id>.json) that narrates it. */
        public String story = "";
        public Build build = new Build();
        /** Optional: a kit id from the story's "kits", given to the player when the episode starts. */
        public String startKit = "";
        /** Optional: a fight id from the story's "fights", spawned when the episode starts. */
        public String startFight = "";
    }

    /** The scene (a .schem schematic) the player is teleported to. */
    public static class Build {
        /** File name inside config/storyengine/schematics/, for example "underworld.schem". */
        public String schematic = "";
        /** Where the lowest corner of the schematic is pasted in the overworld: [x, y, z]. */
        public int[] origin = { 30000, 100, 30000 };
        /** Where the player appears, measured from the origin: [x, y, z]. null = the middle. */
        public int[] spawn = null;
        /** true = air in the schematic replaces terrain too (clears the area first). */
        public boolean pasteAir = true;
    }

    public Episode findEpisode(String id) {
        for (Episode e : episodes) {
            if (e.id.equals(id)) return e;
        }
        return null;
    }
}
