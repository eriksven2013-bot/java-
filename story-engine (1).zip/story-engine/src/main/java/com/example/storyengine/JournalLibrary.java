package com.example.storyengine;

import com.google.gson.Gson;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Loads config/storyengine/journal.json. If it doesn't exist yet, the default one is
 * copied out of the mod jar first, so you can edit it afterwards.
 */
public class JournalLibrary {
    private static final Gson GSON = new Gson();

    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("storyengine").resolve("journal.json");
    private Journal journal = new Journal();
    private String rawJson = "{}";

    public void load() {
        try {
            Files.createDirectories(file.getParent());
            if (!Files.exists(file)) {
                try (InputStream in = JournalLibrary.class.getResourceAsStream("/assets/storyengine/journal.json")) {
                    if (in != null) Files.copy(in, file);
                }
            }
            rawJson = Files.readString(file, StandardCharsets.UTF_8);
            Journal parsed = GSON.fromJson(rawJson, Journal.class);
            journal = parsed == null ? new Journal() : parsed;
        } catch (Exception e) {
            // A broken journal.json shouldn't crash the game: keep an empty journal and say why.
            StoryEngineMod.LOGGER.error("Could not read journal.json: {}", e.getMessage());
            journal = new Journal();
            rawJson = "{}";
        }
        StoryEngineMod.LOGGER.info("Journal loaded: {} characters, {} episodes",
            journal.characters.size(), journal.episodes.size());
    }

    public Journal journal() {
        return journal;
    }

    /** The journal as JSON text, exactly as it will be sent to players. */
    public String json() {
        return rawJson;
    }
}
