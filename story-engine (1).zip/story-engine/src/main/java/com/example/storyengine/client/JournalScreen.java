package com.example.storyengine.client;

import com.example.storyengine.Journal;
import com.example.storyengine.net.StartEpisodePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * The journal. It has four pages:
 *   page 0: pick a character
 *   page 1: pick one of that character's arcs (Empire Arc, Pirate Arc, ...)
 *   page 2: pick one of that arc's episodes
 *   page 3: read about the episode and press Play
 * Press Escape to close it.
 */
public class JournalScreen extends Screen {
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GREY = 0xFFAAAAAA;

    private final Journal journal;
    private int page = 0;
    private Journal.Hero selectedCharacter;
    private Journal.Arc selectedArc;
    private Journal.Episode selectedEpisode;

    public JournalScreen(Journal journal) {
        super(Text.literal("Journal"));
        this.journal = journal;
    }

    @Override
    protected void init() {
        rebuild();
    }

    /** The arcs that belong to the selected character, in the order they are listed. */
    private List<Journal.Arc> arcsOfSelectedCharacter() {
        List<Journal.Arc> result = new ArrayList<>();
        for (Journal.Arc arc : journal.arcs) {
            if (arc.character.equals(selectedCharacter.id)) result.add(arc);
        }
        return result;
    }

    /** The episodes that belong to the selected arc. */
    private List<Journal.Episode> episodesOfSelectedArc() {
        List<Journal.Episode> result = new ArrayList<>();
        for (Journal.Episode episode : journal.episodes) {
            if (episode.arc.equals(selectedArc.id)) result.add(episode);
        }
        return result;
    }

    /** Removes the buttons and adds the right ones for the current page. */
    private void rebuild() {
        clearChildren();
        int centerX = width / 2;
        int y = 70;

        if (page == 0) {
            y = 60;
            for (Journal.Hero hero : journal.characters) {
                addDrawableChild(ButtonWidget.builder(Text.literal(hero.name), button -> {
                    selectedCharacter = hero;
                    page = 1;
                    rebuild();
                }).dimensions(centerX - 100, y, 200, 20).build());
                y += 24;
            }
        } else if (page == 1) {
            for (Journal.Arc arc : arcsOfSelectedCharacter()) {
                addDrawableChild(ButtonWidget.builder(Text.literal(arc.name), button -> {
                    selectedArc = arc;
                    page = 2;
                    rebuild();
                }).dimensions(centerX - 100, y, 200, 20).build());
                y += 24;
            }
            addBackButton(0);
        } else if (page == 2) {
            for (Journal.Episode episode : episodesOfSelectedArc()) {
                String label = episode.playable ? episode.title : episode.title + " (coming soon)";
                addDrawableChild(ButtonWidget.builder(Text.literal(label), button -> {
                    selectedEpisode = episode;
                    page = 3;
                    rebuild();
                }).dimensions(centerX - 140, y, 280, 20).build());
                y += 24;
            }
            addBackButton(1);
        } else {
            ButtonWidget play = ButtonWidget.builder(Text.literal("Play this episode"), button -> {
                // Ask the server to start it, then close the journal.
                ClientPlayNetworking.send(new StartEpisodePayload(selectedEpisode.id));
                close();
            }).dimensions(centerX - 100, height - 56, 200, 20).build();
            play.active = selectedEpisode.playable; // greyed out for "coming soon" episodes
            addDrawableChild(play);
            addBackButton(2);
        }
    }

    /** A "Back" button at the bottom that goes to the given page. */
    private void addBackButton(int toPage) {
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), button -> {
            page = toPage;
            rebuild();
        }).dimensions(width / 2 - 100, height - 30, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta); // draws the background and buttons

        int centerX = width / 2;
        if (page == 0) {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("Choose a character"), centerX, 30, WHITE);
        } else if (page == 1) {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(selectedCharacter.name), centerX, 24, WHITE);
            drawWrapped(context, selectedCharacter.description, centerX, 38, GREY);
            if (arcsOfSelectedCharacter().isEmpty()) {
                drawWrapped(context, "Arcs coming soon.", centerX, 70, GREY);
            }
        } else if (page == 2) {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(selectedArc.name), centerX, 24, WHITE);
            drawWrapped(context, selectedArc.description, centerX, 38, GREY);
            if (episodesOfSelectedArc().isEmpty()) {
                drawWrapped(context, "No episodes here yet.", centerX, 70, GREY);
            }
        } else {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(selectedEpisode.title), centerX, 24, WHITE);
            drawWrapped(context, selectedEpisode.description, centerX, 44, GREY);
        }
    }

    /** Draws text centered, wrapped to fit the screen. */
    private void drawWrapped(DrawContext context, String text, int centerX, int top, int color) {
        if (text == null || text.isEmpty()) return;
        List<OrderedText> lines = textRenderer.wrapLines(StringVisitable.plain(text), Math.min(width - 40, 320));
        int y = top;
        for (OrderedText line : lines) {
            int lineWidth = textRenderer.getWidth(line);
            context.drawTextWithShadow(textRenderer, line, centerX - lineWidth / 2, y, color);
            y += 10;
        }
    }

    @Override
    public boolean shouldPause() {
        return false; // keep the game running while the journal is open
    }
}
