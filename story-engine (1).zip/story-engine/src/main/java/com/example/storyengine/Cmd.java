package com.example.storyengine;

import net.minecraft.server.MinecraftServer;

/** A tiny helper for running server commands without chat spam. */
public final class Cmd {
    private Cmd() {}

    /** Runs a command (no leading slash) as the server, silently. */
    public static void run(MinecraftServer server, String command) {
        server.getCommandManager().executeWithPrefix(server.getCommandSource().withSilent(), command);
    }
}
