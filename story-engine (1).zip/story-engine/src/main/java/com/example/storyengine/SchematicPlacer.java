package com.example.storyengine;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

/**
 * Pastes a schematic into the world a few thousand blocks per tick.
 *
 * Doing it all in one go would freeze the game for several seconds on a big build, so
 * we do a slice each tick (just like StoryRunner counts ticks instead of sleeping).
 */
public class SchematicPlacer {
    private final Schematic schematic;
    private final BlockPos origin;
    private final boolean pasteAir;
    private int next = 0; // the next block position (index) to place

    public SchematicPlacer(Schematic schematic, BlockPos origin, boolean pasteAir) {
        this.schematic = schematic;
        this.origin = origin;
        this.pasteAir = pasteAir;
    }

    /**
     * Places up to 'budget' blocks.
     * @return true when the whole schematic has been placed
     */
    public boolean step(ServerWorld world, int budget) {
        int width = schematic.width;
        int length = schematic.length;
        BlockPos.Mutable pos = new BlockPos.Mutable();
        int placed = 0;

        while (next < schematic.total() && placed < budget) {
            int i = next++;
            BlockState state = schematic.palette[schematic.indices[i]];
            if (state == null || (!pasteAir && state.isAir())) continue;

            // Turn the single index back into x, y, z.
            int x = i % width;
            int z = (i / width) % length;
            int y = i / (width * length);

            pos.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
            world.setBlockState(pos, state, Block.NOTIFY_LISTENERS);
            placed++;
        }
        return next >= schematic.total();
    }

    /** 0 to 100, for the "Building the scene" message. */
    public int percent() {
        return schematic.total() == 0 ? 100 : (int) (next * 100L / schematic.total());
    }
}
