package com.example.storyengine;

import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Runs stories. The game runs at 20 "ticks" per second, and we are called once per tick.
 * Instead of using sleep() (which would freeze the whole server), each running story just
 * counts down a timer and does its next step when the timer reaches zero.
 */
public class StoryRunner {

    /** The state of one player's currently running story. */
    private static class Active {
        final Story story;
        int nextStep = 0;      // which step we will run next
        int ticksToWait = 0;   // how many ticks until we run it

        Active(Story story) {
            this.story = story;
        }
    }

    private final Map<UUID, Active> running = new HashMap<>();

    public void start(ServerPlayerEntity player, Story story) {
        running.put(player.getUuid(), new Active(story));
    }

    /** @return true if the player had a story running */
    public boolean stop(UUID playerId) {
        return running.remove(playerId) != null;
    }

    /** Called every server tick (20 times per second). */
    public void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Active>> it = running.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Active> entry = it.next();
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(entry.getKey());

            // Player left the game: end their story.
            if (player == null) {
                it.remove();
                continue;
            }

            Active active = entry.getValue();
            if (active.ticksToWait > 0) {
                active.ticksToWait--;
                continue;
            }

            // Run steps until one asks us to pause (or the story ends).
            while (active.ticksToWait == 0 && active.nextStep < active.story.steps.size()) {
                Story.Step step = active.story.steps.get(active.nextStep++);
                active.ticksToWait = runStep(server, player, active.story, step);
            }

            if (active.nextStep >= active.story.steps.size() && active.ticksToWait == 0) {
                player.sendMessage(Text.literal("— The End —").formatted(Formatting.GRAY, Formatting.ITALIC), false);
                it.remove();
            }
        }
    }

    /**
     * Performs one step.
     * @return how many ticks to pause afterwards
     */
    private int runStep(MinecraftServer server, ServerPlayerEntity player, Story story, Story.Step step) {
        String type = step.type == null ? "" : step.type.toLowerCase();

        switch (type) {
            case "say" -> {
                Text line = Text.empty();
                if (step.speaker != null && !step.speaker.isEmpty()) {
                    line = Text.literal("[" + step.speaker + "] ").formatted(Formatting.GOLD);
                }
                // 'false' = show in chat (true would show above the hotbar)
                player.sendMessage(line.copy().append(Text.literal(step.text).formatted(Formatting.WHITE)), false);
                return toTicks(step.seconds, 3.0);
            }
            case "actionbar" -> {
                player.sendMessage(Text.literal(step.text).formatted(Formatting.YELLOW), true);
                return toTicks(step.seconds, 3.0);
            }
            case "title" -> {
                // fade in 10 ticks, stay 60 ticks, fade out 10 ticks
                player.networkHandler.sendPacket(new TitleFadeS2CPacket(10, 60, 10));
                player.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal(step.subtitle).formatted(Formatting.GRAY)));
                player.networkHandler.sendPacket(new TitleS2CPacket(Text.literal(step.title).formatted(Formatting.BOLD)));
                return toTicks(step.seconds, 4.0);
            }
            case "command" -> {
                // Runs as the server console, so it works even if the player isn't an operator.
                String command = step.command.replace("{player}", player.getName().getString());
                Cmd.run(server, command);
                return toTicks(step.seconds, 0.0);
            }
            case "kit" -> {
                // Gives the player the gear listed under this name in the story's "kits".
                runAll(server, player, story.kits == null ? null : story.kits.get(step.id), "kit", step.id);
                return toTicks(step.seconds, 0.0);
            }
            case "fight" -> {
                // Spawns the enemies listed under this name in the story's "fights".
                // The story keeps going while the player fights (use "seconds" to pause it instead).
                runAll(server, player, story.fights == null ? null : story.fights.get(step.id), "fight", step.id);
                return toTicks(step.seconds, 0.0);
            }
            case "wait" -> {
                return toTicks(step.seconds, 1.0);
            }
            default -> {
                StoryEngineMod.LOGGER.warn("Unknown step type '{}' in story — skipping it.", step.type);
                return 0;
            }
        }
    }

    /** Gives a kit from the story's "kits" (used when an episode starts). */
    public void runKit(MinecraftServer server, ServerPlayerEntity player, Story story, String id) {
        runAll(server, player, story.kits == null ? null : story.kits.get(id), "kit", id);
    }

    /** Spawns a fight from the story's "fights" (used when an episode starts). */
    public void runFight(MinecraftServer server, ServerPlayerEntity player, Story story, String id) {
        runAll(server, player, story.fights == null ? null : story.fights.get(id), "fight", id);
    }

    /** Runs a list of server commands for this player ({player} becomes their name). */
    private void runAll(MinecraftServer server, ServerPlayerEntity player, java.util.List<String> commands,
                        String what, String id) {
        if (commands == null) {
            StoryEngineMod.LOGGER.warn("This story has no {} called '{}' — skipping it.", what, id);
            return;
        }
        String playerName = player.getName().getString();
        for (String command : commands) {
            Cmd.run(server, command.replace("{player}", playerName));
        }
    }

    /** Converts seconds to ticks, using a default when the story file didn't say. */
    private static int toTicks(double seconds, double defaultSeconds) {
        double s = seconds < 0 ? defaultSeconds : seconds;
        return (int) Math.round(s * 20);
    }
}
