package com.example.storyengine;

import com.example.storyengine.net.JournalSyncPayload;
import com.example.storyengine.net.StartEpisodePayload;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.command.CommandSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * The entry point. Fabric calls onInitialize() once when the game starts (on both the
 * server and the player's game). Here we load everything, hook into the game tick,
 * set up the messages the journal uses to talk to the server, and register /story.
 *
 * Commands:
 *   /story list            - show available stories
 *   /story play <name>     - play a story where you stand (no teleport, no build)
 *   /story episode <id>    - start an episode, same as picking it in the journal
 *   /story leave           - end the episode and go back to where you were
 *   /story stop            - stop the current story
 *   /story reload          - re-read stories and journal.json (handy while writing them)
 *
 * NOTE: these commands are open to every player. If you run this on a public server,
 * add a permission check to "reload" (and think about "play" and "episode" too).
 */
public class StoryEngineMod implements ModInitializer {
    public static final String MOD_ID = "storyengine";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private final StoryLibrary library = new StoryLibrary();
    private final JournalLibrary journals = new JournalLibrary();
    private final StoryRunner runner = new StoryRunner();
    private final EpisodeManager episodes = new EpisodeManager(journals, library, runner);

    @Override
    public void onInitialize() {
        library.load();
        journals.load();
        makeSchematicsFolder();

        // 1. Tell Minecraft about our two custom messages (this must run on both sides).
        PayloadTypeRegistry.playS2C().register(JournalSyncPayload.ID, JournalSyncPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(StartEpisodePayload.ID, StartEpisodePayload.CODEC);

        // 2. When a player joins, send them the journal so the J screen has something to show.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
            sender.sendPacket(new JournalSyncPayload(journals.json())));

        // 3. When a player presses Play in the journal, start that episode.
        ServerPlayNetworking.registerGlobalReceiver(StartEpisodePayload.ID, (payload, context) ->
            episodes.start(context.server(), context.player(), payload.episodeId()));

        // 4. Every server tick, move running stories and episode builds forward.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            runner.tick(server);
            episodes.tick(server);
        });

        // 5. The /story command.
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("story")

                .then(CommandManager.literal("list").executes(ctx -> {
                    StringBuilder names = new StringBuilder();
                    for (String id : library.ids()) {
                        if (names.length() > 0) names.append(", ");
                        names.append(id);
                    }
                    String result = names.length() == 0 ? "(none yet — add .json files to " + library.folder() + ")" : names.toString();
                    ctx.getSource().sendFeedback(() -> Text.literal("Stories: " + result), false);
                    return 1;
                }))

                .then(CommandManager.literal("play")
                    .then(CommandManager.argument("name", StringArgumentType.word())
                        // Tab-complete story names.
                        .suggests((ctx, builder) -> CommandSource.suggestMatching(library.ids(), builder))
                        .executes(ctx -> {
                            String name = StringArgumentType.getString(ctx, "name");
                            Story story = library.get(name);
                            if (story == null) {
                                ctx.getSource().sendError(Text.literal("No story called '" + name + "'. Try /story list"));
                                return 0;
                            }
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            runner.start(player, story);
                            ctx.getSource().sendFeedback(
                                () -> Text.literal("Starting \"" + story.name + "\" by " + story.author), false);
                            return 1;
                        })))

                .then(CommandManager.literal("episode")
                    .then(CommandManager.argument("id", StringArgumentType.word())
                        .suggests((ctx, builder) -> CommandSource.suggestMatching(
                            journals.journal().episodes.stream().filter(e -> e.playable).map(e -> e.id).toList(), builder))
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            episodes.start(ctx.getSource().getServer(), player, StringArgumentType.getString(ctx, "id"));
                            return 1;
                        })))

                .then(CommandManager.literal("leave").executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    boolean wasInEpisode = episodes.leave(ctx.getSource().getServer(), player);
                    ctx.getSource().sendFeedback(
                        () -> Text.literal(wasInEpisode ? "Welcome back." : "You aren't in an episode."), false);
                    return wasInEpisode ? 1 : 0;
                }))

                .then(CommandManager.literal("stop").executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    boolean wasRunning = runner.stop(player.getUuid());
                    ctx.getSource().sendFeedback(
                        () -> Text.literal(wasRunning ? "Story stopped." : "You have no story running."), false);
                    return wasRunning ? 1 : 0;
                }))

                .then(CommandManager.literal("reload").executes(ctx -> {
                    library.load();
                    journals.load();
                    // Send the fresh journal to everyone online.
                    MinecraftServer server = ctx.getSource().getServer();
                    for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                        ServerPlayNetworking.send(p, new JournalSyncPayload(journals.json()));
                    }
                    ctx.getSource().sendFeedback(() -> Text.literal("Stories and journal reloaded."), false);
                    return 1;
                }))
            ));
    }

    /** Makes config/storyengine/schematics/ so you know where to put your .schem files. */
    private void makeSchematicsFolder() {
        try {
            Path schematics = library.folder().getParent().resolve("schematics");
            Files.createDirectories(schematics);
        } catch (Exception e) {
            LOGGER.warn("Could not create the schematics folder: {}", e.getMessage());
        }
    }
}
