package com.example.storyengine;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;

/**
 * A WorldEdit schematic (.schem, the "Sponge" format) loaded into memory.
 *
 * Both Sponge version 2 and version 3 files are understood. Only the blocks are loaded:
 * chests' contents, signs' text and other "block entities" are not pasted.
 *
 * Blocks are stored as a palette (a list of distinct block states) plus one palette number
 * per position, in x-then-z-then-y order: index = (y * length + z) * width + x.
 */
public class Schematic {
    public final int width;
    public final int height;
    public final int length;
    final BlockState[] palette;
    final int[] indices;

    private Schematic(int width, int height, int length, BlockState[] palette, int[] indices) {
        this.width = width;
        this.height = height;
        this.length = length;
        this.palette = palette;
        this.indices = indices;
    }

    public int total() {
        return indices.length;
    }

    /** Reads a .schem file. Throws IOException if it isn't a readable schematic. */
    @SuppressWarnings("unchecked")
    public static Schematic load(Path file) throws IOException {
        Map<String, Object> root = MiniNbt.readGzipped(file);
        // Version 3 wraps everything inside a "Schematic" compound; version 2 doesn't.
        Map<String, Object> s = root.containsKey("Schematic") ? (Map<String, Object>) root.get("Schematic") : root;

        int width = ((Number) require(s, "Width")).intValue() & 0xFFFF;
        int height = ((Number) require(s, "Height")).intValue() & 0xFFFF;
        int length = ((Number) require(s, "Length")).intValue() & 0xFFFF;

        Map<String, Object> paletteTag;
        byte[] data;
        if (s.containsKey("Blocks")) { // version 3
            Map<String, Object> blocks = (Map<String, Object>) s.get("Blocks");
            paletteTag = (Map<String, Object>) require(blocks, "Palette");
            data = (byte[]) require(blocks, "Data");
        } else { // version 2
            paletteTag = (Map<String, Object>) require(s, "Palette");
            data = (byte[]) require(s, "BlockData");
        }

        // The palette maps "minecraft:oak_stairs[facing=north]" -> number. Turn it into a list.
        int max = 0;
        for (Object v : paletteTag.values()) max = Math.max(max, ((Number) v).intValue());
        BlockState[] palette = new BlockState[max + 1];
        for (Map.Entry<String, Object> entry : paletteTag.entrySet()) {
            palette[((Number) entry.getValue()).intValue()] = parseState(entry.getKey());
        }

        // The block data is a list of "varints" (numbers stored in 1 or more bytes).
        int total = width * height * length;
        int[] indices = new int[total];
        int pos = 0;
        for (int i = 0; i < total; i++) {
            int value = 0;
            int shift = 0;
            int b;
            do {
                if (pos >= data.length) throw new IOException("Schematic block data ends too early");
                b = data[pos++] & 0xFF;
                value |= (b & 0x7F) << shift;
                shift += 7;
            } while ((b & 0x80) != 0);
            indices[i] = value;
        }
        return new Schematic(width, height, length, palette, indices);
    }

    /**
     * A simple built-in arena (a stone brick floor with empty space above), used when an
     * episode's schematic file hasn't been added yet so the episode is still playable.
     */
    public static Schematic placeholderArena() {
        int w = 41, h = 12, l = 41;
        BlockState air = Blocks.AIR.getDefaultState();
        BlockState floor = Blocks.STONE_BRICKS.getDefaultState();
        int[] indices = new int[w * h * l];
        for (int z = 0; z < l; z++) {
            for (int x = 0; x < w; x++) {
                indices[(0 * l + z) * w + x] = 1; // y = 0 is the floor, everything else stays 0 (air)
            }
        }
        return new Schematic(w, h, l, new BlockState[] { air, floor }, indices);
    }

    private static Object require(Map<String, Object> map, String key) throws IOException {
        Object value = map.get(key);
        if (value == null) throw new IOException("Schematic is missing '" + key + "'");
        return value;
    }

    /** Turns text like "minecraft:oak_stairs[facing=north,half=bottom]" into a block state. */
    static BlockState parseState(String text) {
        String id = text;
        String props = "";
        int bracket = text.indexOf('[');
        if (bracket >= 0) {
            id = text.substring(0, bracket);
            props = text.substring(bracket + 1, text.length() - 1);
        }
        Identifier identifier = Identifier.tryParse(id);
        if (identifier == null || !Registries.BLOCK.containsId(identifier)) {
            StoryEngineMod.LOGGER.warn("Schematic uses an unknown block '{}' — it will be left out.", id);
            return null;
        }
        Block block = Registries.BLOCK.get(identifier);
        BlockState state = block.getDefaultState();
        if (!props.isEmpty()) {
            for (String pair : props.split(",")) {
                String[] keyValue = pair.split("=", 2);
                if (keyValue.length != 2) continue;
                Property<?> property = block.getStateManager().getProperty(keyValue[0]);
                if (property != null) state = withValue(state, property, keyValue[1]);
            }
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState withValue(BlockState state, Property<T> property, String value) {
        return property.parse(value).map(parsed -> state.with(property, parsed)).orElse(state);
    }
}
