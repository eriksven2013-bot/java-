package com.example.storyengine;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Starts episodes. When a player picks an episode in the journal this:
 *   1. remembers where the player was,
 *   2. pastes the episode's schematic far away in the overworld (a slice per tick),
 *   3. teleports the player into it,
 *   4. gives the start kit and spawns the start fight (if the episode has them),
 *   5. starts the episode's story, which gives more kits and spawns more enemies scene by scene.
 */
public class EpisodeManager {
    private static final int BLOCKS_PER_TICK = 4000;

    /** An episode that is still being built. */
    private static class Pending {
        final Journal.Episode episode;
        final Story story;
        final SchematicPlacer placer;
        final BlockPos origin;
        final int[] spawn;
        int ticks = 0;

        Pending(Journal.Episode episode, Story story, SchematicPlacer placer, BlockPos origin, int[] spawn) {
            this.episode = episode;
            this.story = story;
            this.placer = placer;
            this.origin = origin;
            this.spawn = spawn;
        }
    }

    /** Where a player was before they entered an episode, so /story leave can send them back. */
    private record ReturnPoint(String dimension, double x, double y, double z, float yaw, float pitch) {}

    private final JournalLibrary journals;
    private final StoryLibrary stories;
    private final StoryRunner runner;
    private final Map<UUID, Pending> pending = new HashMap<>();
    private final Map<UUID, ReturnPoint> returnPoints = new HashMap<>();

    public EpisodeManager(JournalLibrary journals, StoryLibrary stories, StoryRunner runner) {
        this.journals = journals;
        this.stories = stories;
        this.runner = runner;
    }

    public void start(MinecraftServer server, ServerPlayerEntity player, String episodeId) {
        Journal.Episode episode = journals.journal().findEpisode(episodeId);
        if (episode == null || !episode.playable) {
            tell(player, "That episode can't be played yet.");
            return;
        }
        if (pending.containsKey(player.getUuid())) {
            tell(player, "Your episode is still being built — one moment.");
            return;
        }
        Story story = stories.get(episode.story);
        if (story == null) {
            tell(player, "This episode's story file '" + episode.story + "' wasn't found.");
            return;
        }

        // Load the schematic, or fall back to the built-in arena so the episode still works.
        Journal.Build build = episode.build == null ? new Journal.Build() : episode.build;
        Schematic schematic = loadSchematic(player, build.schematic);

        int[] originArray = (build.origin != null && build.origin.length == 3) ? build.origin : new int[] { 30000, 100, 30000 };
        BlockPos origin = new BlockPos(originArray[0], originArray[1], originArray[2]);
        int[] spawn = (build.spawn != null && build.spawn.length == 3)
            ? build.spawn
            : new int[] { schematic.width / 2, 2, schematic.length / 2 };

        // Remember where they were (but not if they're already inside another episode).
        returnPoints.putIfAbsent(player.getUuid(), currentPoint(server, player));
        runner.stop(player.getUuid());

        pending.put(player.getUuid(), new Pending(episode, story,
            new SchematicPlacer(schematic, origin, build.pasteAir), origin, spawn));
        player.sendMessage(Text.literal("Building the scene...").formatted(Formatting.YELLOW), true);
    }

    /** Called every server tick: pastes a slice of each pending build, and finishes the ones that are done. */
    public void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Pending>> it = pending.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Pending> entry = it.next();
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(entry.getKey());
            if (player == null) { // they logged off mid-build
                it.remove();
                returnPoints.remove(entry.getKey());
                continue;
            }

            Pending job = entry.getValue();
            boolean done = job.placer.step(server.getOverworld(), BLOCKS_PER_TICK);
            job.ticks++;
            if (!done) {
                if (job.ticks % 20 == 0) {
                    player.sendMessage(Text.literal("Building the scene... " + job.placer.percent() + "%")
                        .formatted(Formatting.YELLOW), true);
                }
                continue;
            }

            it.remove();
            finish(server, player, job);
        }
    }

    private void finish(MinecraftServer server, ServerPlayerEntity player, Pending job) {
        String name = player.getName().getString();
        double x = job.origin.getX() + job.spawn[0] + 0.5;
        double y = job.origin.getY() + job.spawn[1];
        double z = job.origin.getZ() + job.spawn[2] + 0.5;
        Cmd.run(server, String.format(Locale.ROOT, "execute in minecraft:overworld run tp %s %.1f %.1f %.1f", name, x, y, z));

        player.sendMessage(Text.literal(job.episode.title).formatted(Formatting.GOLD, Formatting.BOLD), true);

        // Gear for the player and enemies that exist from the very start of the episode.
        if (job.episode.startKit != null && !job.episode.startKit.isEmpty()) {
            runner.runKit(server, player, job.story, job.episode.startKit);
        }
        if (job.episode.startFight != null && !job.episode.startFight.isEmpty()) {
            runner.runFight(server, player, job.story, job.episode.startFight);
        }

        // Now the story takes over: dialogue, and more kits and fights at the right scenes.
        runner.start(player, job.story);
    }

    /** Sends the player back to where they were and ends their story. */
    public boolean leave(MinecraftServer server, ServerPlayerEntity player) {
        pending.remove(player.getUuid());
        runner.stop(player.getUuid());
        ReturnPoint back = returnPoints.remove(player.getUuid());
        if (back == null) return false;

        Cmd.run(server, "kill @e[tag=storyengine_fight]"); // clears the episode's enemies
        Cmd.run(server, String.format(Locale.ROOT, "execute in %s run tp %s %.1f %.1f %.1f %.1f %.1f",
            back.dimension(), player.getName().getString(), back.x(), back.y(), back.z(), back.yaw(), back.pitch()));
        return true;
    }

    private Schematic loadSchematic(ServerPlayerEntity player, String fileName) {
        if (fileName != null && !fileName.isEmpty()) {
            Path file = stories.folder().getParent().resolve("schematics").resolve(fileName);
            if (Files.exists(file)) {
                try {
                    return Schematic.load(file);
                } catch (IOException | RuntimeException e) {
                    StoryEngineMod.LOGGER.error("Could not read schematic {}: {}", file, e.getMessage());
                    tell(player, "The schematic '" + fileName + "' couldn't be read, so a plain arena is used instead.");
                    return Schematic.placeholderArena();
                }
            }
            tell(player, "Schematic '" + fileName + "' not found in config/storyengine/schematics, so a plain arena is used instead.");
        }
        return Schematic.placeholderArena();
    }

    private ReturnPoint currentPoint(MinecraftServer server, ServerPlayerEntity player) {
        // Find which dimension the player is standing in.
        String dimension = "minecraft:overworld";
        for (ServerWorld world : server.getWorlds()) {
            if (world.getPlayers().contains(player)) {
                dimension = world.getRegistryKey().getValue().toString();
                break;
            }
        }
        return new ReturnPoint(dimension, player.getX(), player.getY(), player.getZ(), player.getYaw(), player.getPitch());
    }

    private void tell(ServerPlayerEntity player, String message) {
        player.sendMessage(Text.literal(message).formatted(Formatting.RED), false);
    }
}
