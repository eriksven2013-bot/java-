package com.example.storyengine;

import java.util.List;
import java.util.Map;

/**
 * A story loaded from a JSON file. Gson fills these fields in automatically,
 * so the field names must match the keys in the JSON file.
 *
 * Example JSON:
 * {
 *   "name": "My Story",
 *   "author": "Me",
 *   "steps": [ { "type": "say", "speaker": "Narrator", "text": "Hello!" } ]
 * }
 */
public class Story {
    public String name = "Untitled";
    public String author = "Unknown";
    public List<Step> steps = List.of();

    /**
     * Named kits. Each kit is a list of server commands (no leading slash) that give the player
     * gear, potions, effects and so on. A "kit" step runs every command in the kit it names.
     */
    public Map<String, List<String>> kits = Map.of();

    /**
     * Named fights. Each fight is a list of server commands, usually "summon" commands, that spawn
     * the enemies. A "fight" step runs every command in the fight it names.
     */
    public Map<String, List<String>> fights = Map.of();

    /** One thing that happens in the story. Which fields are used depends on "type". */
    public static class Step {
        /** say, title, actionbar, wait, command, kit or fight */
        public String type = "say";

        // kit / fight: the name of the kit or fight (a key in "kits" or "fights" above)
        public String id = "";

        // say
        public String speaker = "";
        public String text = "";

        // title
        public String title = "";
        public String subtitle = "";

        // command (a server command WITHOUT the leading slash; {player} is replaced by the player's name)
        public String command = "";

        /** Seconds to pause AFTER this step. -1 means "use the default for this step type". */
        public double seconds = -1;
    }
}
