package com.example.storyengine.client;

import com.example.storyengine.Journal;
import com.example.storyengine.net.StartEpisodePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * The journal: ONE screen with a tab bar, a list on the left and details on the right.
 *
 *   top bar     : tabs (only "Story" works so far, the rest say "coming soon")
 *   left panel  : "Playing as <character>" switcher + the arcs and their episodes (scrolls)
 *   right panel : the selected episode (title, badge, typed-out description, buttons)
 *   bottom bar  : a one-line hint
 *
 * Animations: the window slides and fades in, list rows fade in one after another,
 * the tab underline glides, hovered things glow, the description types itself out,
 * the list scrolls smoothly and the Play button pulses.
 *
 * How it is drawn: every clickable thing is a FlatButton (a ButtonWidget whose
 * look we replaced). "Layers" are FlatButtons that can't be clicked and only paint.
 */
public class JournalScreen extends Screen {
    // ---- colours (ARGB) ----
    private static final int PANEL = 0xF0121A26;
    private static final int PANEL_LIGHT = 0xF01A2535;
    private static final int FRAME = 0xFF2C4A63;
    private static final int ACCENT = 0xFF4FD0E8;
    private static final int GOLD = 0xFFE0B04A;
    private static final int GREEN = 0xFF4FD070;
    private static final int TEXT = 0xFFE8EEF4;
    private static final int DIM = 0xFF8EA0B2;

    private static final String[] TABS = { "STORY", "FREEPLAY", "KITS", "CODEX", "MAP", "TROPHIES", "MULTIPLAYER" };

    // ---- journal data and selection ----
    private final Journal journal;
    private int tab = 0;
    private int heroIndex = 0;
    private Journal.Episode selected;

    // ---- layout (filled in by init) ----
    private int px, py, pw, ph;           // the whole window
    private int listX, listY, listW, listH; // the scrolling list viewport
    private int detX, detY, detW, detH;   // the right panel
    private int tabW;

    // ---- animation state ----
    private long openStart = System.currentTimeMillis();
    private long rowsStart = System.currentTimeMillis();
    private long typeStart = System.currentTimeMillis();
    private float tabUnderlineX = -1;
    private float scroll = 0, scrollTarget = 0;
    private int contentHeight = 0;
    private float alpha = 0;   // 0..1 while opening
    private int offY = 0;      // slide offset while opening

    private final List<FlatButton> animated = new ArrayList<>(); // everything that slides with the window
    private final List<Row> rows = new ArrayList<>();

    public JournalScreen(Journal journal) {
        super(Text.literal("Journal"));
        this.journal = journal;
        selectFirstEpisodeOfHero();
    }

    // =====================================================================
    //  data helpers
    // =====================================================================

    private Journal.Hero hero() {
        if (journal.characters.isEmpty()) return null;
        return journal.characters.get(heroIndex);
    }

    private void selectFirstEpisodeOfHero() {
        selected = null;
        Journal.Hero hero = hero();
        if (hero == null) return;
        Journal.Episode firstAny = null;
        for (Journal.Arc arc : journal.arcs) {
            if (!arc.character.equals(hero.id)) continue;
            for (Journal.Episode episode : journal.episodes) {
                if (!episode.arc.equals(arc.id)) continue;
                if (firstAny == null) firstAny = episode;
                if (episode.playable && selected == null) selected = episode;
            }
        }
        if (selected == null) selected = firstAny;
        typeStart = System.currentTimeMillis();
    }

    private Journal.Arc arcOf(Journal.Episode episode) {
        for (Journal.Arc arc : journal.arcs) {
            if (arc.id.equals(episode.arc)) return arc;
        }
        return null;
    }

    /** One line of the left list. */
    private static class Row {
        static final int HEADER = 0, EPISODE = 1, EMPTY = 2;
        int kind;
        String text;
        Journal.Episode episode;
        int height;
        int y; // position inside the list, before scrolling
        FlatButton button;
    }

    private void buildRows() {
        rows.clear();
        Journal.Hero hero = hero();
        if (hero == null) return;
        boolean anyArc = false;
        for (Journal.Arc arc : journal.arcs) {
            if (!arc.character.equals(hero.id)) continue;
            anyArc = true;
            rows.add(row(Row.HEADER, arc.name, null, 20));
            boolean anyEpisode = false;
            for (Journal.Episode episode : journal.episodes) {
                if (!episode.arc.equals(arc.id)) continue;
                anyEpisode = true;
                rows.add(row(Row.EPISODE, episode.title, episode, 20));
            }
            if (!anyEpisode) rows.add(row(Row.EMPTY, "Coming soon", null, 14));
        }
        if (!anyArc) rows.add(row(Row.EMPTY, "Arcs coming soon", null, 18));
        int y = 0;
        for (Row r : rows) {
            r.y = y;
            y += r.height;
        }
        contentHeight = y + 6;
    }

    private Row row(int kind, String text, Journal.Episode episode, int height) {
        Row r = new Row();
        r.kind = kind;
        r.text = text;
        r.episode = episode;
        r.height = height;
        return r;
    }

    // =====================================================================
    //  building the widgets
    // =====================================================================

    @Override
    protected void init() {
        rebuild();
    }

    private void rebuild() {
        clearChildren();
        animated.clear();
        buildRows();

        pw = Math.min(width - 16, 580);
        ph = Math.min(height - 16, 320);
        px = (width - pw) / 2;
        py = (height - ph) / 2;

        int contentTop = py + 30;
        int contentBottom = py + ph - 24;
        int leftW = Math.max(150, pw * 2 / 5);
        int leftX = px + 8;
        detX = leftX + leftW + 8;
        detW = px + pw - 8 - detX;
        detY = contentTop;
        detH = contentBottom - contentTop;

        // Layer 1: the frame, panels, tab bar background, bottom bar
        addLayer(this::paintBackdrop);

        // Tabs
        tabW = (pw - 16) / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            final int index = i;
            FlatButton b = new FlatButton(px + 8 + i * tabW, py + 6, tabW, 18, Text.literal(TABS[i]), button -> {
                if (tab != index) {
                    tab = index;
                    typeStart = System.currentTimeMillis();
                }
            });
            b.painter = (self, c, hover) -> {
                boolean current = index == tab;
                int color = current ? ACCENT : blend(DIM, TEXT, hover);
                centered(c, TABS[index], self.getX() + self.getWidth() / 2, self.getY() + 5, fade(color));
            };
            add(b);
        }

        if (tab == 0) buildStoryTab(leftX, leftW, contentTop, contentBottom);

        // Layer last: the bottom hint and the glowing frame corners
        addLayer(this::paintForeground);
    }

    private void buildStoryTab(int leftX, int leftW, int contentTop, int contentBottom) {
        // --- character switcher (top of the left panel) ---
        int switchH = 24;
        FlatButton prev = new FlatButton(leftX + leftW - 38, contentTop + 4, 16, 16, Text.literal("<"), b -> cycleHero(-1));
        FlatButton next = new FlatButton(leftX + leftW - 20, contentTop + 4, 16, 16, Text.literal(">"), b -> cycleHero(1));
        prev.painter = (self, c, hover) -> arrow(c, self, "<", hover);
        next.painter = (self, c, hover) -> arrow(c, self, ">", hover);
        prev.active = next.active = journal.characters.size() > 1;
        addLayer((self, c, hover) -> paintSwitcher(c, leftX, contentTop, leftW, switchH));
        add(prev);
        add(next);

        // --- scrolling list ---
        listX = leftX;
        listY = contentTop + switchH + 6;
        listW = leftW;
        listH = contentBottom - listY;
        addLayer((self, c, hover) -> fillRect(c, listX, listY, listW, listH, fade(PANEL_LIGHT)));
        for (Row r : rows) {
            FlatButton b = new FlatButton(listX + 2, listY, listW - 10, r.height,
                Text.literal(r.text), button -> {
                    if (r.kind == Row.EPISODE) {
                        selected = r.episode;
                        typeStart = System.currentTimeMillis();
                    }
                });
            b.active = r.kind == Row.EPISODE;
            b.painter = (self, c, hover) -> paintRow(c, self, r, hover);
            r.button = b;
            add(b);
        }
        addLayer((self, c, hover) -> paintScrollbar(c));

        // --- details (right panel) ---
        addLayer((self, c, hover) -> paintDetails(c));
        if (selected != null) {
            int by = detY + detH - 26;
            FlatButton play = new FlatButton(detX + 8, by, detW - 16, 20, Text.literal("PLAY"), b -> {
                ClientPlayNetworking.send(new StartEpisodePayload(selected.id));
                close();
            });
            play.active = selected.playable;
            play.painter = (self, c, hover) -> paintPlay(c, self, hover);
            add(play);

            int half = (detW - 16 - 4) / 2;
            FlatButton restart = new FlatButton(detX + 8, by - 24, half, 18, Text.literal("RESTART"), b -> {
                ClientPlayNetworking.send(new StartEpisodePayload(selected.id));
                close();
            });
            restart.active = selected.playable;
            restart.painter = (self, c, hover) -> paintSmallButton(c, self, "RESTART", ACCENT, hover);
            add(restart);

            FlatButton stop = new FlatButton(detX + 8 + half + 4, by - 24, half, 18, Text.literal("STOP STORY"), b -> {
                runCommand("story leave");
                runCommand("story stop");
                close();
            });
            stop.painter = (self, c, hover) -> paintSmallButton(c, self, "STOP STORY", 0xFFE06060, hover);
            add(stop);
        }
    }

    private void cycleHero(int direction) {
        int n = journal.characters.size();
        if (n == 0) return;
        heroIndex = (heroIndex + direction + n) % n;
        scroll = scrollTarget = 0;
        rowsStart = System.currentTimeMillis();
        selectFirstEpisodeOfHero();
        rebuild();
    }

    private void runCommand(String command) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) client.player.networkHandler.sendChatCommand(command);
    }

    private void add(FlatButton b) {
        b.baseY = b.getY();
        animated.add(b);
        addDrawableChild(b);
    }

    private void addLayer(FlatButton.Painter painter) {
        FlatButton layer = new FlatButton(0, 0, width, height, Text.empty(), b -> {});
        layer.active = false;
        layer.painter = painter;
        layer.isLayer = true;
        addDrawableChild(layer);
    }

    // =====================================================================
    //  per-frame update
    // =====================================================================

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();

        // opening animation
        float t = clamp01((now - openStart) / 420f);
        float ease = 1 - (1 - t) * (1 - t) * (1 - t);
        alpha = ease;
        offY = Math.round((1 - ease) * 18);

        // smooth scrolling
        float maxScroll = Math.max(0, contentHeight - listH);
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        scroll += (scrollTarget - scroll) * 0.25f;
        if (Math.abs(scrollTarget - scroll) < 0.1f) scroll = scrollTarget;

        // tab underline glide
        float wantedX = px + 8 + tab * tabW;
        if (tabUnderlineX < 0) tabUnderlineX = wantedX;
        tabUnderlineX += (wantedX - tabUnderlineX) * 0.22f;

        // move everything that slides, and position the list rows
        for (FlatButton b : animated) {
            b.setY(b.baseY + offY);
        }
        for (Row r : rows) {
            if (r.button == null) continue;
            int y = listY + 2 + r.y - Math.round(scroll) + offY;
            r.button.setY(y);
            r.button.visible = y + r.height > listY + offY && y < listY + listH + offY;
        }

        super.render(context, mouseX, mouseY, delta); // draws the dark background, then all our widgets
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (tab == 0 && mouseX >= listX && mouseX <= listX + listW && mouseY >= listY && mouseY <= listY + listH) {
            scrollTarget -= (float) (verticalAmount * 22);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean shouldPause() {
        return false; // keep the game running while the journal is open
    }

    // =====================================================================
    //  painters
    // =====================================================================

    private void paintBackdrop(FlatButton self, DrawContext c, float hover) {
        int y = py + offY;
        // soft shadow + window
        fillRect(c, px - 3, y - 3, pw + 6, ph + 6, fade(0x66000000));
        c.fillGradient(px, y, px + pw, y + ph, fade(0xF0141E2C), fade(0xF00C121C));
        outline(c, px, y, pw, ph, fade(FRAME));
        // tab bar
        fillRect(c, px + 4, y + 4, pw - 8, 22, fade(0xF00E1520));
        fillRect(c, px + 4, y + 25, pw - 8, 1, fade(FRAME));
        // gliding underline
        fillRect(c, Math.round(tabUnderlineX) + 4, y + 23, Math.max(4, tabW - 8), 2, fade(ACCENT));
        // bottom bar
        fillRect(c, px + 4, y + ph - 20, pw - 8, 16, fade(0xF00E1520));
        // right panel
        fillRect(c, detX, detY + offY, detW, detH, fade(PANEL));
        outline(c, detX, detY + offY, detW, detH, fade(0xFF22384D));
    }

    private void paintForeground(FlatButton self, DrawContext c, float hover) {
        int y = py + offY;
        // glowing corner diamonds
        float pulse = 0.6f + 0.4f * (float) Math.sin(System.currentTimeMillis() / 400.0);
        int glow = withAlpha(GOLD, pulse * alpha);
        diamond(c, px - 1, y - 1, glow);
        diamond(c, px + pw - 3, y - 1, glow);
        diamond(c, px - 1, y + ph - 3, glow);
        diamond(c, px + pw - 3, y + ph - 3, glow);

        // tabs other than Story: a big "coming soon" panel
        if (tab != 0) {
            fillRect(c, px + 8, py + 30 + offY, pw - 16, ph - 54, fade(PANEL));
            outline(c, px + 8, py + 30 + offY, pw - 16, ph - 54, fade(0xFF22384D));
            centered(c, TABS[tab], px + pw / 2, py + ph / 2 - 14 + offY, fade(ACCENT));
            centered(c, "Coming soon", px + pw / 2, py + ph / 2 + offY, fade(DIM));
        }

        // bottom hint
        String hint;
        if (tab != 0) hint = "Now: " + TABS[tab].charAt(0) + TABS[tab].substring(1).toLowerCase() + " is coming soon.";
        else if (selected == null) hint = "Now: Pick a character and an episode.";
        else hint = "Now: " + selected.title;
        text(c, trim(hint, pw - 24), px + 10, y + ph - 16, fade(DIM));
    }

    private void paintSwitcher(DrawContext c, int x, int y, int w, int h) {
        int yy = y + offY;
        fillRect(c, x, yy, w, h, fade(0xF0182A3C));
        outline(c, x, yy, w, h, fade(ACCENT));
        diamond(c, x + 5, yy + 9, fade(ACCENT));
        Journal.Hero hero = hero();
        text(c, "PLAYING AS", x + 16, yy + 3, fade(DIM));
        if (hero != null) text(c, trim(hero.name, w - 70), x + 16, yy + 13, fade(TEXT));
        // little dots: one per character, the current one is bright
        int n = journal.characters.size();
        for (int i = 0; i < n; i++) {
            int color = i == heroIndex ? ACCENT : 0xFF34506A;
            fillRect(c, x + w - 42 - (n - i) * 5, yy + 10, 3, 3, fade(color));
        }
    }

    private void arrow(DrawContext c, FlatButton self, String symbol, float hover) {
        int color = self.active ? blend(DIM, ACCENT, hover) : 0xFF34506A;
        fillRect(c, self.getX(), self.getY(), self.getWidth(), self.getHeight(), fade(withAlpha(0xFF22384D, 0.8f + 0.2f * hover)));
        centered(c, symbol, self.getX() + self.getWidth() / 2, self.getY() + 4, fade(color));
    }

    private void paintRow(DrawContext c, FlatButton self, Row r, float hover) {
        // rows fade in one after another
        float rowFade = clamp01((System.currentTimeMillis() - rowsStart - rows.indexOf(r) * 35L) / 260f);
        float a = rowFade;
        int x = self.getX(), y = self.getY(), w = self.getWidth(), h = self.getHeight();
        c.enableScissor(listX, listY + offY, listX + listW, listY + listH + offY);
        if (r.kind == Row.HEADER) {
            text(c, r.text.toUpperCase(), x + 4, y + 8, fade(withAlpha(GOLD, a)));
            fillRect(c, x + 4, y + 18, w - 8, 1, fade(withAlpha(0xFF2C4A63, a)));
        } else if (r.kind == Row.EMPTY) {
            text(c, "  " + r.text, x + 8, y + 3, fade(withAlpha(0xFF5C6E80, a)));
        } else {
            boolean isSelected = r.episode == selected;
            if (isSelected) {
                fillRect(c, x, y, w, h, fade(withAlpha(0xFF1E3A52, a)));
                fillRect(c, x, y, 2, h, fade(withAlpha(ACCENT, a)));
            } else if (hover > 0.01f) {
                fillRect(c, x, y, w, h, fade(withAlpha(0xFF182C40, a * hover)));
            }
            int dot = r.episode.playable ? GREEN : 0xFF5C6E80;
            fillRect(c, x + 8, y + 8, 4, 4, fade(withAlpha(dot, a)));
            int color = isSelected ? TEXT : blend(r.episode.playable ? 0xFFB8C6D4 : 0xFF6C7E90, TEXT, hover);
            int nudge = Math.round(hover * 2); // hovered rows slide right a little
            text(c, trim(r.text, w - 24), x + 18 + nudge, y + 6, fade(withAlpha(color, a)));
        }
        c.disableScissor();
    }

    private void paintScrollbar(DrawContext c) {
        if (contentHeight <= listH) return;
        int x = listX + listW - 5;
        int y = listY + offY;
        fillRect(c, x, y + 2, 3, listH - 4, fade(0xFF0E1520));
        float visible = (float) listH / contentHeight;
        int barH = Math.max(14, Math.round((listH - 4) * visible));
        float maxScroll = contentHeight - listH;
        int barY = y + 2 + Math.round((listH - 4 - barH) * (maxScroll <= 0 ? 0 : scroll / maxScroll));
        fillRect(c, x, barY, 3, barH, fade(ACCENT));
    }

    private void paintDetails(DrawContext c) {
        int x = detX + 8;
        int y = detY + offY + 8;
        int w = detW - 16;

        if (selected == null) {
            Journal.Hero hero = hero();
            text(c, hero == null ? "No characters yet." : hero.name, x, y, fade(TEXT));
            text(c, "Nothing to play here yet.", x, y + 14, fade(DIM));
            return;
        }
        Journal.Arc arc = arcOf(selected);
        text(c, trim(arc == null ? "EPISODE" : arc.name.toUpperCase(), w), x, y, fade(GOLD));
        text(c, trim(selected.title, w), x, y + 12, fade(TEXT));

        // status badge
        String badge = selected.playable ? "PLAYABLE" : "COMING SOON";
        int badgeColor = selected.playable ? GREEN : 0xFF6C7E90;
        int bw = textRenderer.getWidth(badge) + 10;
        fillRect(c, x, y + 26, bw, 12, fade(withAlpha(badgeColor, 0.25f)));
        outline(c, x, y + 26, bw, 12, fade(badgeColor));
        text(c, badge, x + 5, y + 28, fade(badgeColor));

        // description, typed out one character at a time
        String description = selected.description == null || selected.description.isEmpty()
            ? "No description yet." : selected.description;
        int chars = (int) ((System.currentTimeMillis() - typeStart) * 0.07);
        int dy = y + 46;
        int limitY = detY + offY + detH - 62; // keep clear of the buttons
        for (String line : wrap(description, w)) {
            if (chars <= 0 || dy + 9 > limitY) break;
            String shown = line.length() <= chars ? line : line.substring(0, chars);
            text(c, shown, x, dy, fade(0xFFC8D4E0));
            chars -= line.length() + 1;
            dy += 11;
        }
    }

    private void paintPlay(DrawContext c, FlatButton self, float hover) {
        int x = self.getX(), y = self.getY(), w = self.getWidth(), h = self.getHeight();
        if (!self.active) {
            fillRect(c, x, y, w, h, fade(0xFF1A2330));
            outline(c, x, y, w, h, fade(0xFF34506A));
            centered(c, "NOT PLAYABLE YET", x + w / 2, y + 6, fade(0xFF5C6E80));
            return;
        }
        float pulse = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 350.0);
        int fill = blend(0xFF1F5E73, 0xFF2A87A3, Math.max(hover, pulse * 0.35f));
        fillRect(c, x, y, w, h, fade(fill));
        outline(c, x, y, w, h, fade(withAlpha(ACCENT, 0.6f + 0.4f * Math.max(hover, pulse))));
        centered(c, "> PLAY", x + w / 2, y + 6, fade(TEXT));
    }

    private void paintSmallButton(DrawContext c, FlatButton self, String label, int color, float hover) {
        int x = self.getX(), y = self.getY(), w = self.getWidth(), h = self.getHeight();
        if (!self.active) {
            fillRect(c, x, y, w, h, fade(0xFF1A2330));
            outline(c, x, y, w, h, fade(0xFF34506A));
            centered(c, label, x + w / 2, y + 5, fade(0xFF5C6E80));
            return;
        }
        fillRect(c, x, y, w, h, fade(withAlpha(color, 0.12f + 0.25f * hover)));
        outline(c, x, y, w, h, fade(withAlpha(color, 0.6f + 0.4f * hover)));
        centered(c, label, x + w / 2, y + 5, fade(blend(color, TEXT, hover)));
    }

    // =====================================================================
    //  small drawing helpers
    // =====================================================================

    private void fillRect(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x, y, x + w, y + h, color);
    }

    private void outline(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x, y, x + w, y + 1, color);
        c.fill(x, y + h - 1, x + w, y + h, color);
        c.fill(x, y, x + 1, y + h, color);
        c.fill(x + w - 1, y, x + w, y + h, color);
    }

    private void diamond(DrawContext c, int x, int y, int color) {
        c.fill(x + 1, y, x + 3, y + 4, color);
        c.fill(x, y + 1, x + 4, y + 3, color);
    }

    private void text(DrawContext c, String s, int x, int y, int color) {
        if ((color >>> 24) < 5) return; // nearly invisible text would draw fully opaque
        c.drawTextWithShadow(textRenderer, Text.literal(s), x, y, color);
    }

    private void centered(DrawContext c, String s, int cx, int y, int color) {
        text(c, s, cx - textRenderer.getWidth(s) / 2, y, color);
    }

    /** Cuts text so it fits in the width, adding "..." if needed. */
    private String trim(String s, int maxWidth) {
        if (textRenderer.getWidth(s) <= maxWidth) return s;
        String cut = s;
        while (cut.length() > 1 && textRenderer.getWidth(cut + "...") > maxWidth) {
            cut = cut.substring(0, cut.length() - 1);
        }
        return cut + "...";
    }

    /** Word-wraps text to the given pixel width. */
    private List<String> wrap(String s, int maxWidth) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String attempt = line.length() == 0 ? word : line + " " + word;
            if (textRenderer.getWidth(attempt) > maxWidth && line.length() > 0) {
                lines.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(attempt);
            }
        }
        if (line.length() > 0) lines.add(line.toString());
        return lines;
    }

    /** Applies the opening fade to a colour. */
    private int fade(int color) {
        return withAlpha(color, alpha);
    }

    private static int withAlpha(int argb, float factor) {
        int a = Math.round(((argb >>> 24) & 0xFF) * clamp01(factor));
        return (a << 24) | (argb & 0xFFFFFF);
    }

    private static int blend(int from, int to, float t) {
        t = clamp01(t);
        int a = Math.round(((from >>> 24) & 0xFF) * (1 - t) + ((to >>> 24) & 0xFF) * t);
        int r = Math.round(((from >> 16) & 0xFF) * (1 - t) + ((to >> 16) & 0xFF) * t);
        int g = Math.round(((from >> 8) & 0xFF) * (1 - t) + ((to >> 8) & 0xFF) * t);
        int b = Math.round((from & 0xFF) * (1 - t) + (to & 0xFF) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static float clamp01(float v) {
        return v < 0 ? 0 : Math.min(v, 1);
    }

    // =====================================================================
    //  FlatButton: a button whose look we draw ourselves
    // =====================================================================

    private static class FlatButton extends ButtonWidget {
        interface Painter {
            void paint(FlatButton self, DrawContext context, float hover);
        }

        Painter painter;
        int baseY;
        float hover = 0;
        boolean isLayer = false;

        FlatButton(int x, int y, int w, int h, Text label, ButtonWidget.PressAction onPress) {
            super(x, y, w, h, label, onPress, DEFAULT_NARRATION_SUPPLIER);
        }

        /** We draw the whole button ourselves, so we replace render() (the same call Minecraft makes on every widget). */
        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            if (!visible) return;
            boolean over = mouseX >= getX() && mouseX < getX() + getWidth()
                && mouseY >= getY() && mouseY < getY() + getHeight();
            float target = (!isLayer && active && over) ? 1f : 0f;
            hover += (target - hover) * 0.3f;
            if (painter != null) painter.paint(this, context, hover);
        }
    }
}
