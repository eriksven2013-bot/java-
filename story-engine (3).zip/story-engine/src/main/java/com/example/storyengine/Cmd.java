package com.example.storyengine;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** A tiny helper for running server commands without chat spam. */
public final class Cmd {
    private static final Logger LOG = LoggerFactory.getLogger("storyengine");

    private Cmd() {}

    /** Runs a command (no leading slash) as the server, silently. */
    public static void run(MinecraftServer server, String command) {
        if (command.startsWith("/")) command = command.substring(1);
        try {
            // Uses Brigadier's own dispatcher, whose method names stay the same between versions.
            server.getCommandManager().getDispatcher()
                    .execute(command, server.getCommandSource().withSilent());
        } catch (CommandSyntaxException e) {
            LOG.warn("Story command failed: '{}' -> {}", command, e.getMessage());
        } catch (RuntimeException e) {
            LOG.warn("Story command crashed: '{}' -> {}", command, e.toString());
        }
    }
}
